-- MySQL dump 10.13  Distrib 5.1.44, for apple-darwin8.11.1 (i386)
--
-- Host: localhost    Database: MZ2
-- ------------------------------------------------------
-- Server version	5.1.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `qid` bigint(20) NOT NULL,
  `type_id` bigint(20) NOT NULL,
  `Type` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
INSERT INTO `activity` VALUES (1,1,1,1,'asked','2010-07-10','00:00:19'),(2,1,1,1,'asked','2010-07-18','02:31:17'),(3,1,1,1,'asked','2010-07-18','02:33:11'),(4,1,1,1,'asked','2010-07-18','02:33:23'),(5,1,1,1,'asked','2010-07-18','02:39:12'),(6,1,1,1,'asked','2010-07-18','02:42:30'),(7,1,1,1,'asked','2010-07-18','03:01:16'),(8,1,1,1,'asked','2010-07-18','03:01:19'),(9,1,1,1,'asked','2010-07-18','03:02:05'),(10,1,1,1,'asked','2010-07-18','03:02:07'),(11,1,1,1,'asked','2010-07-18','03:02:41'),(12,1,1,1,'asked','2010-07-18','03:02:43'),(13,1,1,1,'asked','2010-07-18','03:02:53'),(14,1,1,1,'asked','2010-07-18','03:04:11'),(15,1,1,1,'asked','2010-07-18','03:05:30'),(16,1,1,1,'asked','2010-07-18','03:05:36'),(17,1,1,1,'asked','2010-07-18','03:05:44'),(18,1,1,1,'asked','2010-07-18','03:05:47'),(19,1,1,1,'asked','2010-07-18','03:05:58'),(20,1,1,1,'asked','2010-07-18','03:06:06'),(21,1,1,1,'asked','2010-07-18','03:06:38'),(22,1,1,1,'asked','2010-07-18','03:06:39'),(23,1,1,1,'asked','2010-07-18','03:06:53'),(24,1,1,1,'asked','2010-07-18','03:06:59'),(25,1,1,1,'asked','2010-07-18','03:07:09'),(26,1,1,1,'asked','2010-07-18','03:08:34'),(27,1,1,1,'asked','2010-07-18','03:08:45'),(28,1,1,1,'asked','2010-07-18','03:10:04'),(29,1,1,1,'asked','2010-07-18','03:11:25'),(30,1,1,1,'asked','2010-07-18','03:11:57'),(31,1,1,1,'asked','2010-07-18','03:14:09'),(32,1,1,1,'asked','2010-07-18','03:14:48'),(33,1,1,1,'asked','2010-07-18','03:15:23'),(34,1,1,1,'asked','2010-07-18','03:16:06'),(35,1,1,1,'asked','2010-07-18','03:19:04'),(36,1,1,1,'asked','2010-07-18','03:21:13'),(37,1,1,1,'asked','2010-07-18','03:21:45'),(38,1,1,1,'asked','2010-07-18','03:23:26'),(39,1,1,1,'asked','2010-07-18','03:24:02'),(40,1,1,1,'asked','2010-07-18','03:29:21');
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `answer` text,
  `right_answer` tinyint(1) DEFAULT NULL,
  `vote_up` int(11) DEFAULT '0',
  `vote_down` int(11) DEFAULT '0',
  `time` time NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `answer` (`answer`(255)),
  KEY `question_id` (`question_id`),
  CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) DEFAULT NULL,
  `answer_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `comment` (`comment`(255)),
  KEY `question_id` (`question_id`),
  KEY `answer_id` (`answer_id`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,1,0,1,'I\'m testing for edit');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `latest_activity`
--

DROP TABLE IF EXISTS `latest_activity`;
/*!50001 DROP VIEW IF EXISTS `latest_activity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `latest_activity` (
  `act_id` bigint(20),
  `user_id` int(11),
  `username` varchar(50),
  `question` varchar(255),
  `qid` bigint(20),
  `type_id` bigint(20),
  `Type` varchar(10),
  `date` date,
  `time` time
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `question_text` text NOT NULL,
  `vote_up` int(11) DEFAULT '0',
  `vote_down` int(11) DEFAULT '0',
  `time` time NOT NULL,
  `date` date NOT NULL,
  `view` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `question` (`vote_up`,`date`,`time`,`question`),
  KEY `question_text` (`question_text`(255))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,1,'iPhone 4 ကို ရန္ကုန္မွာ သံုးလုိ႕ရလား။ &lt;script&gt;&lt;/script&gt;','iPhone 4 မွာ ရန္ကုန္က Sim ေတြ နဲ႕ သံုးလုိ႕ရပါသလား။ သံုးလုိ႕ရေအာင္ ဘယ္လိုလုပ္ရမလဲ။',0,0,'03:16:06','2010-07-18',0);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_tag`
--

DROP TABLE IF EXISTS `question_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `question_id` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_tag`
--

LOCK TABLES `question_tag` WRITE;
/*!40000 ALTER TABLE `question_tag` DISABLE KEYS */;
INSERT INTO `question_tag` VALUES (5,1,14);
/*!40000 ALTER TABLE `question_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `question_view`
--

DROP TABLE IF EXISTS `question_view`;
/*!50001 DROP VIEW IF EXISTS `question_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `question_view` (
  `user_id` int(11),
  `question_id` bigint(20),
  `username` varchar(50),
  `email` varchar(255),
  `reputation` int(11),
  `user_type` varchar(10),
  `question` varchar(255),
  `question_text` text,
  `vote_up` int(11),
  `vote_down` int(11),
  `vote` bigint(12),
  `time` time,
  `date` date,
  `view` bigint(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rule`
--

DROP TABLE IF EXISTS `rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reputation` int(11) DEFAULT NULL,
  `rule` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule`
--

LOCK TABLES `rule` WRITE;
/*!40000 ALTER TABLE `rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Name` (`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (24,'64-bit\r'),(142,'addons\r'),(124,'adobe-photoshop\r'),(167,'Android'),(93,'anti-virus\r'),(134,'apache\r'),(68,'apple\r'),(82,'applications\r'),(40,'audio\r'),(21,'backup\r'),(41,'bash\r'),(108,'bios\r'),(38,'boot\r'),(34,'browser\r'),(152,'c-sharp\r'),(162,'CMS\r'),(16,'command-line\r'),(96,'configuration\r'),(127,'connection\r'),(97,'convert\r'),(51,'cpu\r'),(145,'cyber-cafe\r'),(98,'debain\r'),(80,'desktop\r'),(133,'display\r'),(107,'dns\r'),(151,'dot-net\r'),(76,'download\r'),(26,'drivers\r'),(89,'dual-boot\r'),(86,'dvd\r'),(147,'ebook\r'),(17,'email\r'),(132,'encryption\r'),(67,'error\r'),(164,'exam'),(27,'excel\r'),(75,'external-harddrive\r'),(165,'facebook'),(57,'file\r'),(83,'file-management\r'),(99,'filesystem\r'),(9,'firefox\r'),(91,'firefox-addon\r'),(92,'flash\r'),(106,'folder\r'),(94,'fonts\r'),(161,'framework\r'),(138,'freeware\r'),(104,'ftp\r'),(36,'gmail\r'),(88,'gnome\r'),(66,'google\r'),(33,'google-chrome\r'),(116,'graphic\r'),(117,'graphic-card\r'),(13,'hard-drive\r'),(11,'hardware\r'),(129,'html\r'),(128,'icon\r'),(146,'IDM\r'),(46,'image\r'),(77,'install\r'),(43,'installation\r'),(29,'internet\r'),(61,'internet-explorer\r'),(14,'iPhone\r'),(166,'iPhone'),(168,'iPhone-SDK'),(32,'iTunes\r'),(130,'java\r'),(163,'javascript\r'),(121,'joomla\r'),(159,'jquery\r'),(160,'json\r'),(25,'keyboard\r'),(35,'keyboard-shortcuts\r'),(12,'laptop\r'),(3,'linux\r'),(123,'login\r'),(7,'mac\r'),(126,'macbook\r'),(90,'macbook-pro\r'),(73,'memory\r'),(136,'microsoft\r'),(59,'microsoft-office\r'),(48,'microsoft-word\r'),(28,'monitor\r'),(87,'motherboard\r'),(63,'mouse\r'),(100,'mp3\r'),(122,'music\r'),(1,'mysql'),(55,'network\r'),(10,'networking\r'),(125,'office\r'),(139,'open-source\r'),(101,'operation-system\r'),(5,'osx\r'),(30,'outlook\r'),(49,'partition\r'),(70,'password\r'),(53,'pdf\r'),(39,'performance\r'),(155,'perl\r'),(111,'php\r'),(103,'plugins\r'),(115,'power-supply\r'),(71,'printer\r'),(110,'printing\r'),(150,'programming\r'),(118,'proxy\r'),(154,'python\r'),(79,'ram\r'),(60,'remote-desktop\r'),(157,'ROR\r'),(37,'router\r'),(156,'ruby\r'),(119,'script\r'),(19,'security\r'),(109,'server\r'),(105,'sftp\r'),(135,'sharing\r'),(74,'shell\r'),(143,'shortcuts\r'),(20,'snow-leopard\r'),(18,'software\r'),(81,'sound\r'),(114,'speed\r'),(50,'ssh\r'),(54,'subjective\r'),(141,'svn\r'),(56,'sync\r'),(102,'taskbar\r'),(69,'terminal\r'),(95,'thunderbird\r'),(113,'tools\r'),(45,'troubleshooting\r'),(158,'twitter\r'),(6,'ubuntu\r'),(149,'unicode\r'),(31,'unix\r'),(140,'update\r'),(23,'usb\r'),(62,'usb-flash-drive\r'),(153,'vb\r'),(15,'video\r'),(112,'videocard\r'),(72,'vim\r'),(47,'virtual-machine\r'),(44,'virtualbox\r'),(78,'virtualization\r'),(131,'virus\r'),(42,'vmware\r'),(84,'vpn\r'),(137,'web\r'),(144,'webcam\r'),(64,'website\r'),(65,'wifi\r'),(2,'windows\r'),(85,'windows-explorer\r'),(8,'windows-vista\r'),(4,'windows-xp\r'),(22,'wireless\r'),(120,'wordpress\r'),(148,'zawgyi\r');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `tag_list`
--

DROP TABLE IF EXISTS `tag_list`;
/*!50001 DROP VIEW IF EXISTS `tag_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `tag_list` (
  `question_id` bigint(20),
  `tag_id` int(11),
  `question` varchar(255),
  `tag_name` varchar(30)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `salt` varchar(32) DEFAULT NULL,
  `website` varchar(80) DEFAULT NULL,
  `location` text,
  `Bio` text,
  `reputation` int(11) DEFAULT '0',
  `join_date` date DEFAULT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='User Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'saturngod@gmail.com','saturngod','cc0287dab4831290e4712ae83d175c9a','968d7e1083d2a5a82530a3103fa8ca41','http://en.saturngod','Singapore','I\'m saturngod',0,'2010-05-01','admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `latest_activity`
--

/*!50001 DROP TABLE IF EXISTS `latest_activity`*/;
/*!50001 DROP VIEW IF EXISTS `latest_activity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_activity` AS select `activity`.`id` AS `act_id`,`user`.`id` AS `user_id`,`user`.`username` AS `username`,`question`.`question` AS `question`,`question`.`id` AS `qid`,`activity`.`type_id` AS `type_id`,`activity`.`Type` AS `Type`,`activity`.`date` AS `date`,`activity`.`time` AS `time` from ((`user` join `activity`) join `question`) where ((`user`.`id` = `activity`.`user_id`) and (`question`.`id` = `activity`.`qid`)) order by `activity`.`date` desc,`activity`.`time` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `question_view`
--

/*!50001 DROP TABLE IF EXISTS `question_view`*/;
/*!50001 DROP VIEW IF EXISTS `question_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `question_view` AS select `user`.`id` AS `user_id`,`question`.`id` AS `question_id`,`user`.`username` AS `username`,`user`.`email` AS `email`,`user`.`reputation` AS `reputation`,`user`.`type` AS `user_type`,`question`.`question` AS `question`,`question`.`question_text` AS `question_text`,`question`.`vote_up` AS `vote_up`,`question`.`vote_down` AS `vote_down`,(`question`.`vote_up` - `question`.`vote_down`) AS `vote`,`question`.`time` AS `time`,`question`.`date` AS `date`,`question`.`view` AS `view` from (`question` join `user`) where (`user`.`id` = `question`.`user_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tag_list`
--

/*!50001 DROP TABLE IF EXISTS `tag_list`*/;
/*!50001 DROP VIEW IF EXISTS `tag_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tag_list` AS select `question_tag`.`question_id` AS `question_id`,`question_tag`.`tag_id` AS `tag_id`,`question`.`question` AS `question`,`tag`.`Name` AS `tag_name` from ((`question_tag` join `question`) join `tag`) where ((`question_tag`.`question_id` = `question`.`id`) and (`question_tag`.`tag_id` = `tag`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-07-19  0:04:52
